package mk.ukim.finki.wp.lab.service.impl;

import mk.ukim.finki.wp.lab.model.Album;
import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.model.Song;
import mk.ukim.finki.wp.lab.repository.ArtistRepository;
import mk.ukim.finki.wp.lab.repository.SongRepository;
import mk.ukim.finki.wp.lab.service.SongService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SongServiceImpl implements SongService {
    private final SongRepository songRepository;
    private final ArtistRepository artistRepository;

    public SongServiceImpl(SongRepository songRepository,ArtistRepository artistRepository){
        this.songRepository=songRepository;
        this.artistRepository=artistRepository;
    }

    @Override
    public List<Song> listSongs() {
        return songRepository.findAll();
    }

    @Override
    public Artist addArtistToSong(Artist artist, Song song) {
        return songRepository.addArtistToSong(artist,song);
    }

    @Override
    public Song findById(Long trackId) {
        return songRepository.findById(trackId);
    }

    @Override
    public double averageRating(Song song) {
        return songRepository.getAverageRating(song);
    }

    @Override
    public Optional<Song> findByTitle(String title) {
        return Optional.of(songRepository.findByTitle(title));
    }

    @Override
    public Optional<Song> findByTrackId(String trackId) {
        return Optional.of(songRepository.findByTrackId(trackId));
    }

    @Override
    public Optional<Song> save(String trackId, String title, String genre, Integer releaseYear, Album album) {
        return songRepository.save(title,trackId,genre,releaseYear,album);
    }

    @Override
    public void delete(Long id) {
        songRepository.delete(id);
    }
}
